from django.shortcuts import render
from django.http import HttpResponse
import joblib
import pandas as pd

# Create your views here.

reloadModel = joblib.load('./models/Pcos.pkl')

from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client['pcosDataBase']
collectionD = db['pcosTable']

def index(request):
	temp={}
	temp['Age (yrs)']=28
	temp['BMI']=19.3
	temp['Cycle(R/I)']=0
	temp['Weight gain(Y/N)']=0
	temp['hairgrowth(Y/N)']=0
	temp['Skin darkening (Y/N)']=0
	temp['Hair loss(Y/N)']=0
	temp['Pimples(Y/N)']=0
	temp['Fast food (Y/N)']=1
	temp['Reg.Exercise(Y/N)']=0
	context={'temp':temp}
	return render(request, 'index.html', context)

def classifyPCOS(request):
	if request.method == 'POST':
		print (request.POST.dict())
		temp={}
		temp['Age (yrs)'] = request.POST.get('Age (yrs)')
		temp['BMI'] = request.POST.get('BMI')
		temp['Cycle(R/I)'] = request.POST.get('Cycle(R/I)')
		temp['Weight gain(Y/N)'] = request.POST.get('Weight gain(Y/N)')
		temp['hairgrowth(Y/N)'] = request.POST.get('hairgrowth(Y/N)')
		temp['Skin darkening (Y/N)'] = request.POST.get('Skin darkening (Y/N)')
		temp['Hair loss(Y/N)'] = request.POST.get('Hair loss(Y/N)')
		temp['Pimples(Y/N)'] = request.POST.get('Pimples(Y/N)')
		temp['Fast food (Y/N)'] = request.POST.get('Fast food (Y/N)')
		temp['Reg.Exercise(Y/N)'] = request.POST.get('Reg.Exercise(Y/N)')

	testData = pd.DataFrame({'x':temp}).transpose()
	scoreval = reloadModel.predict(testData)[0]
	context={'scoreval':scoreval,'temp':temp}
	return render(request, 'index.html, context')

	def viewDataBase(request):
		Countofrow=collectionD.find().count()
		context={'Countofrow':Countofrow}
		return render(request, 'viewDB.html', context)

	def updateDataBase(request):
		temp={}
		temp['Age (yrs)'] = request.POST.get('Age (yrs)')
		temp['BMI'] = request.POST.get('BMI')
		temp['Cycle(R/I)'] = request.POST.get('Cycle(R/I)')
		temp['Weight gain(Y/N)'] = request.POST.get('Weight gain(Y/N)')
		temp['hairgrowth(Y/N)'] = request.POST.get('hairgrowth(Y/N)')
		temp['Skin darkening (Y/N)'] = request.POST.get('Skin darkening (Y/N)')
		temp['Hair loss(Y/N)'] = request.POST.get('Hair loss(Y/N)')
		temp['Pimples(Y/N)'] = request.POST.get('Pimples(Y/N)')
		temp['Fast food (Y/N)'] = request.POST.get('Fast food (Y/N)')
		temp['Reg.Exercise(Y/N)'] = request.POST.get('Reg.Exercise(Y/N)')
		temp['PCOS'] = request.POST.get('PCOS')

		pp=collectionD.insert_one(temp)
		
		Countofrow=collectionD.find().count()
		context={'Countofrow':Countofrow}
		return render(request, 'viewDB.html', context)